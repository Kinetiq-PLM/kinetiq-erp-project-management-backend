__version__ = "4.2.0"


DEFAULT_CHANNEL_LAYER = "default"
